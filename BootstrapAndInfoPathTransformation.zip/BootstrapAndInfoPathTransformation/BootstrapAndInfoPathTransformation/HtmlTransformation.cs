﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Regex;

namespace HtmlTransformation
{
    public class HtmltoXSLT
    {
        static string nodePrefix = Transformation.Program.nodePrefix;
        static string testElementName = Transformation.Program.testElementName;
        static string generateDateTime = Transformation.Program.generateDateTime;
        static string nameSpaceDateTimeXsl = Transformation.Program.nameSpaceDateTimeXsl;

        static HtmlDocument htmlDoc = Transformation.Program.htmlDoc;       // For Web Form HTML in Bootstrap Format
        static XmlDocument elemDefinitionDoc = Transformation.Program.elemDefinitionDoc;
        static XmlDocument xsltTMPL = Transformation.Program.xsltTMPL;        // For the InfoPath XSLT Template File in XML Format

        static int newTMPLSecNr = 1;
        static int containerSectionNr = 1;
        static int ctrlNr = 1;
        static int modeNr = 1;
        static int index = 1;

        static XmlElement rootXSL;                              // the root element of  XSLT Template File (XSL:stylesheet)        
        static XmlNode firstXslTempContent;                     // the body part of the first <xsl:template> in generated XSLT file


        //public static void TransformHtmltoXslt(string generateXsltPath, HtmlNodeCollection htmlBodyNodes, XmlDocument xsltTMPL)
        public static void TransformHtmltoXslt(HtmlNodeCollection htmlBodyNodes, XmlDocument xsltTMPL)
        {
            /* Generation of XSLT File from BootStrap HTML */
            try
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = true;                                 // auto-indent the output.
                XmlWriter writer = XmlWriter.Create(Transformation.Program.generateXsltPath, settings);

                /* Generate XSLT file from Template Files*/
                //GenerateXSLT_TMPL(htmlBodyNodes);
                GenerateXSLT_TMPL(htmlBodyNodes, xsltTMPL);
                xsltTMPL.Save(writer);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine("{0}: {1}", e.GetType().Name, e.Message);
            }
        }


        private static void GenerateXSLT_TMPL(HtmlNodeCollection htmlBodyNodes, XmlDocument xsltTMPL)
        {
            // Load the XSLT template stylesheet and Setup namespace attribute value.
            rootXSL = xsltTMPL.DocumentElement;
            rootXSL.SetAttribute("xmlns:" + nodePrefix, nameSpaceDateTimeXsl);
            // get the xsl:template Node`s /html/body/div/table/tbody/tr/td element
            firstXslTempContent = rootXSL.LastChild.SelectSingleNode("//td");

            foreach (HtmlNode htmlbodyNode in htmlBodyNodes)
            {
                HtmlNodeCollection bodyChildNodes = htmlbodyNode.ChildNodes;
                if (bodyChildNodes.Count > 0)
                {
                    foreach (HtmlNode bodyChild in bodyChildNodes)
                    {
                        XmlNode bodyChildSecNode = GenerateSecXSLT_TMPL(bodyChild, firstXslTempContent);
                    }
                }
            }
        }


        private static XmlNode NewXSLTemplateSecGenerate(HtmlNode htmlNode, XmlNode rootNode)
        {
            //Import two ChildNodes of <ApplyTemplateDef> from InfoPathElementDefinition.xml to xsltTMPL.xsl
            XmlNode divRoot = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("ApplyTemplateDef").FirstChild, true);
            XmlNode newTemplate = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("NewTemplateDef").FirstChild, true);
            string bindingName = "";

            if ((htmlNode.HasAttributes) && (htmlNode.Attributes["Id"] != null) && (htmlNode.Attributes["Id"].Value != ""))
            {
                bindingName = nodePrefix + ":" + htmlNode.Attributes["Id"].Value;
            }
            else
            {
                if (htmlNode.Name == "table")
                {
                    bindingName = nodePrefix + ":" + "Table" + newTMPLSecNr.ToString();
                }
                else if ((htmlNode.Name == "div") && (htmlNode.Attributes["class"].Value == "row"))
                {
                    bindingName = nodePrefix + ":" + "GridRow" + newTMPLSecNr.ToString();
                }
                else if ((htmlNode.Name == "div") && (htmlNode.Attributes["class"].Value == "container"))
                {
                    bindingName = nodePrefix + ":" + "Container" + newTMPLSecNr.ToString();
                }
                else if ((htmlNode.Name == "div") && (htmlNode.Attributes["class"].Value == "form-group"))
                {
                    bindingName = nodePrefix + ":" + "Form" + newTMPLSecNr.ToString();
                }
            }

            divRoot.InnerXml = Regex.Replace(divRoot.InnerXml, "LEAF_XPATH1", bindingName);
            divRoot.InnerXml = Regex.Replace(divRoot.InnerXml, "MODE_NUM", "_" + modeNr.ToString());
            rootNode.AppendChild(divRoot);

            newTemplate.Attributes["match"].Value = bindingName;
            newTemplate.Attributes["mode"].Value = "_" + modeNr.ToString();
            rootXSL.AppendChild(newTemplate);

            newTMPLSecNr++;
            modeNr++;
            return newTemplate;
        }


        private static XmlNode NewDivGenerate(HtmlNode node)
        {
            XmlNode div = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("DivDef").FirstChild, true);
            XmlNode font = div.FirstChild;
            font = CopyNodeStyleAttri(node, font);
            return div;
        }


        private static XmlNode CopyNodeAttri(HtmlNode htmlNode, XmlNode xmlNode)
        {
            HtmlAttributeCollection htmlAttriList = htmlNode.Attributes;
            string attriName, attriValue;

            if (htmlAttriList != null)
            {
                foreach (HtmlAttribute htmlAttri in htmlAttriList)
                {
                    attriName = htmlAttri.Name;
                    attriValue = htmlAttri.Value;

                    if (xmlNode.Attributes[attriName] != null)
                    {
                        xmlNode.Value = attriValue;
                    }
                    else
                    {
                        XmlAttribute newAttri = xsltTMPL.CreateAttribute(attriName, "");
                        newAttri.Value = attriValue;
                        xmlNode.Attributes.Append(newAttri);
                    }
                }
            }

            return xmlNode;
        }


        private static XmlNode CopyNodeStyleAttri(HtmlNode htmlNode, XmlNode xmlNode)
        {
            if (xmlNode.Attributes["style"] == null)
            {
                XmlAttribute styleAttri = xsltTMPL.CreateAttribute("style", "");
                xmlNode.Attributes.Append(styleAttri);
            }

            if ((htmlNode.Attributes != null) && (htmlNode.Attributes["style"] != null) && (htmlNode.Attributes["style"].Value != ""))
            {
                xmlNode.Attributes["style"].Value = htmlNode.Attributes["style"].Value;
            }

            if (((htmlNode.Name == "td") || (htmlNode.Name == "th")) && (htmlNode.HasAttributes))
            {
                if (htmlNode.Attributes["colspan"] != null)
                {
                    XmlAttribute colspanAttri = xsltTMPL.CreateAttribute("colspan", "");
                    colspanAttri.Value = htmlNode.Attributes["colspan"].Value;
                    xmlNode.Attributes.Append(colspanAttri);
                }

                if (htmlNode.Attributes["rowspan"] != null)
                {
                    XmlAttribute rowspanAttri = xsltTMPL.CreateAttribute("rowspan", "");
                    rowspanAttri.Value = htmlNode.Attributes["rowspan"].Value;
                    xmlNode.Attributes.Append(rowspanAttri);
                }
            }
            return xmlNode;
        }


        private static XmlNode ColumnWidthCALC(HtmlNode node, XmlNode colgroup)
        {
            XmlNode col = xsltTMPL.CreateNode(XmlNodeType.Element, "", "col", "");

            int beginIndex = node.Attributes["style"].Value.ToUpper().IndexOf("WIDTH");
            string value = node.Attributes["style"].Value.ToUpper().Substring(beginIndex);
            int endIndex = beginIndex + value.IndexOf(";");
            value = node.Attributes["style"].Value.ToUpper().Substring(beginIndex, endIndex - beginIndex);
            value = Regex.Replace(value, "PX", "px");

            if ((col.Attributes != null) && (col.Attributes["style"] != null))
            {
                col.Attributes["style"].Value = value;
            }
            else
            {
                XmlAttribute colAttr = xsltTMPL.CreateAttribute("style", "");
                colAttr.Value = value;
                col.Attributes.Append(colAttr);
            }
            colgroup.AppendChild(col);
            return colgroup;
        }


        private static XmlNode GenerateSecXSLT_TMPL(HtmlNode htmlNode, XmlNode secNode)
        {
            XmlNode root = secNode;
            XmlNode childNode;

            if (htmlNode.Name == "div")
            {
                if ((htmlNode.HasAttributes) && (htmlNode.Attributes["class"] != null) && (htmlNode.Attributes["class"].Value != "")
                    && (htmlNode.Attributes["class"].Value != "form-group") && (!htmlNode.Attributes["class"].Value.StartsWith("col")))
                {
                    XmlNode newNode = NewXSLTemplateSecGenerate(htmlNode, root);

                    if (htmlNode.Attributes["class"].Value.Contains("container"))
                    {   // A General Container.
                        childNode = XSLT_TemplateContainerNode(htmlNode);
                        newNode.AppendChild(childNode);
                    }
                    else if (htmlNode.Attributes["class"].Value.Contains("row"))
                    {   // A GridRow Container.
                        childNode = XSLT_TemplateGridRowNode(htmlNode);
                        newNode.AppendChild(childNode);
                    }

                    rootXSL.AppendChild(newNode);
                    containerSectionNr++;
                    modeNr++;
                }
                else
                {   // General div container (NOT container and GridRow)
                    XmlNode div = NewDivGenerate(htmlNode);
                    HtmlNodeCollection htmlChildNodes = htmlNode.ChildNodes;
                    if (htmlChildNodes.Count > 0)
                    {
                        foreach (HtmlNode htmlChildNode in htmlChildNodes)
                        {
                            childNode = GenerateSecXSLT_TMPL(htmlChildNode, div.FirstChild);
                        }
                    }
                    root.AppendChild(div);
                }
            }
            else if (htmlNode.Name == "table")
            {   // A Table Container.
                XmlNode newNode = NewXSLTemplateSecGenerate(htmlNode, root);
                childNode = XSLT_TemplateTableNode(htmlNode);
                newNode.AppendChild(childNode);
                rootXSL.AppendChild(newNode);
                containerSectionNr++;
                modeNr++;
            }
            else if (htmlNode.Name == "form")
            {   // A Form Container.
                //XmlNode newNode = NewXSLTemplateSecGenerate(htmlNode, root);
                //childNode = XSLT_TemplateFormElement(htmlNode);
                //newNode.AppendChild(childNode);
                //rootXSL.AppendChild(newNode);
                //containerSectionNr++;
                //modeNr++;
            }
            else if ((htmlNode.Name == "input") && (htmlNode.Attributes["type"].Value.Contains("text")))
            {   // A Text Box Node.                     
                childNode = XSLT_TemplateTextBoxElement(htmlNode);
                root.AppendChild(xsltTMPL.ImportNode(childNode, true));
            }
            else if ((htmlNode.Name == "label") && (htmlNode.HasAttributes) && (htmlNode.Attributes["class"] != null) && (htmlNode.Attributes["class"].Value.Contains("checkbox")))
            {   // A Checkbox Node. 
                // "display:inline" - elements are in the same line in the form
                if ((htmlNode.ParentNode.HasAttributes) && (htmlNode.ParentNode.Attributes["style"] != null) &&
                    (htmlNode.ParentNode.Attributes["style"].Value.Contains("display: inline")) &&
                    (htmlNode.PreviousSibling != null) && (htmlNode.PreviousSibling.Name == "label") &&
                    (htmlNode.PreviousSibling.Attributes["class"].Value.Contains("checkbox")))
                {
                    string fontInnerXml = root.SelectSingleNode("div/font").InnerXml;
                    childNode = XSLT_TemplateCheckBoxElement(htmlNode);
                    root.SelectSingleNode("div/font").InnerXml = fontInnerXml + childNode.OuterXml + htmlNode.InnerText.Replace("&nbsp;", "");
                }
                else
                {
                    XmlNode div = NewDivGenerate(htmlNode);
                    childNode = XSLT_TemplateCheckBoxElement(htmlNode);
                    div.FirstChild.InnerXml = childNode.OuterXml + htmlNode.InnerText.Replace("&nbsp;", "");
                    root.AppendChild(div);
                }
            }
            else if (htmlNode.Name == "select")
            {
                // A Dropdown list Node. 
                childNode = XSLT_TemplateDropDownListElement(htmlNode);
                root.AppendChild(childNode);
            }
            else if ((htmlNode.Name == "label") && (htmlNode.HasAttributes) && (htmlNode.Attributes["class"] != null) && (htmlNode.Attributes["class"].Value.Contains("radio")))
            {
                // An Option Buttons Node.
                // "display:inline" - elements are in the same line in the form
                if ((htmlNode.ParentNode.HasAttributes) && (htmlNode.ParentNode.Attributes["style"] != null) &&
                    (htmlNode.ParentNode.Attributes["style"].Value.Contains("display: inline")) &&
                    (htmlNode.PreviousSibling != null) && (htmlNode.PreviousSibling.Name == "label") &&
                    (htmlNode.PreviousSibling.Attributes["class"].Value.Contains("radio")))
                {
                    string fontInnerXml = root.SelectSingleNode("div/font").InnerXml;
                    childNode = XSLT_TemplateOptionButtonsElement(htmlNode, index);
                    root.SelectSingleNode("div/font").InnerXml = fontInnerXml + childNode.OuterXml + htmlNode.InnerText.Replace("&nbsp;", "");
                    index++;
                }
                else
                {
                    XmlNode div = NewDivGenerate(htmlNode);
                    childNode = XSLT_TemplateOptionButtonsElement(htmlNode, index);
                    div.FirstChild.InnerXml = childNode.OuterXml + htmlNode.InnerText.Replace("&nbsp;", "");
                    root.AppendChild(div);
                    index++;
                }
            }
            else if (htmlNode.Name == "button")
            {
                // A Button Node.
                childNode = XSLT_TemplateButtonElement(htmlNode);
                root.AppendChild(childNode);
            }
            else if ((htmlNode.Name == "input") && (htmlNode.Attributes["type"].Value.Contains("file")))
            {
                // A FileInput Node 
                childNode = XSLT_TemplateInputFileElement(htmlNode);
                root.AppendChild(childNode);
            }
            else if (htmlNode.Name == "img")
            {
                // A Image Node.
                childNode = XSLT_TemplateImageElement(htmlNode);
                root.AppendChild(childNode);
            }
            else if (htmlNode.Name == "a")
            {
                // A Link Node.
                childNode = XSLT_TemplateLinkElement(htmlNode);
                root.AppendChild(childNode);
            }
            else if ((htmlNode.Name == "b") || (htmlNode.Name.StartsWith("h")))
            {
                // A Heading Node.
                childNode = XSLT_TemplateHeadingNode(htmlNode);
                root.AppendChild(childNode);
            }
            else if (((htmlNode.Name == "label") && (!htmlNode.HasChildNodes)) || (htmlNode.Name == "#text")
                || (htmlNode.Name == "font") || (htmlNode.Name == "strong") || (htmlNode.Name == "span"))
            {
                // A Label Node.
                childNode = XSLT_TemplateLabelNode(htmlNode);
                root.AppendChild(childNode);
            }
            return root;
        }


        private static XmlNode XSLT_TemplateGridRowNode(HtmlNode node)
        {
            XmlNode div = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("GridRowDef").FirstChild, true);
            XmlNode tr = div.SelectSingleNode("//tr");
            XmlNode colgroup = div.SelectSingleNode("//colgroup");

            HtmlNodeCollection rowCellList = node.ChildNodes;
            if (rowCellList.Count > 0)
            {
                foreach (HtmlNode rowCell in rowCellList)
                {
                    XmlNode td = xsltTMPL.CreateNode(XmlNodeType.Element, "td", "");
                    tr.AppendChild(td);
                    td = CopyNodeStyleAttri(rowCell, td);

                    if ((rowCell.Attributes["style"] != null) && (rowCell.Attributes["style"].Value.ToUpper().Contains("WIDTH:")))
                    {
                        colgroup = ColumnWidthCALC(rowCell, colgroup);
                    }
                    else
                    {   // the width of Row Cell is not defined.
                        int cellPixel = (759 / rowCellList.Count);
                        td.Attributes["style"].Value += "WIDTH:" + cellPixel.ToString() + ";";
                    }
                    td = GenerateSecXSLT_TMPL(rowCell, td);
                }
            }

            div.Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
            ctrlNr++;
            return div;
        }


        private static XmlNode XSLT_TemplateTableNode(HtmlNode node)
        {
            XmlNode divMain = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("TableDef").FirstChild, true);
            XmlNode table = divMain.SelectSingleNode("//table");
            XmlNode colgroup = table.SelectSingleNode("//colgroup");
            int columnNumber = 0;

            table = CopyNodeStyleAttri(node, table);

            HtmlNodeCollection tSecNodeList = node.SelectNodes("*[name()='thead' or name()='tbody']");
            if(tSecNodeList != null)
            {
                if (tSecNodeList.Count > 0)
                {
                    foreach (HtmlNode tSecNode in tSecNodeList)
                    {
                        XmlNode tSec = xsltTMPL.CreateNode(XmlNodeType.Element, "", tSecNode.Name, "");
                        table.AppendChild(tSec);
                        //XmlAttribute vAlign = xsltTMPL.CreateAttribute("vAlign");
                        //vAlign.Value = "top";
                        //tSec.Attributes.Append(vAlign);

                        HtmlNodeCollection tRowNodeList = tSecNode.ChildNodes;
                        if (tRowNodeList.Count > 0)
                        {
                            foreach (HtmlNode tRowNode in tRowNodeList)
                            {
                                if (tRowNode.Name.Equals("tr"))
                                {
                                    XmlNode tRow = xsltTMPL.CreateNode(XmlNodeType.Element, "", tRowNode.Name, "");
                                    tSec.AppendChild(tRow);
                                    tRow = CopyNodeStyleAttri(tRowNode, tRow);

                                    if ((tRowNode.Name == "tr") && (tRowNode.HasChildNodes))
                                    {
                                        int currentColumnNr = (int)tRowNode.SelectNodes("*[name()='th' or name()='td']").Count;
                                        if (currentColumnNr > columnNumber)
                                        {
                                            columnNumber = currentColumnNr;
                                        }
                                    }

                                    HtmlNodeCollection tCellNodeList = tRowNode.ChildNodes;
                                    if (tCellNodeList.Count > 0)
                                    {
                                        foreach (HtmlNode tCellNode in tCellNodeList)
                                        {
                                            if ((tCellNode.Name.Equals("th")) || (tCellNode.Name.Equals("td")))
                                            {
                                                XmlNode cell = xsltTMPL.CreateNode(XmlNodeType.Element, "", tCellNode.Name, "");
                                                tRow.AppendChild(cell);
                                                cell = CopyNodeStyleAttri(tCellNode, cell);

                                                if (((int)colgroup.ChildNodes.Count < columnNumber) && (tCellNode.Attributes["style"] != null)
                                                     && (tCellNode.Attributes["style"].Value.ToUpper().Contains("WIDTH:")))
                                                {
                                                    colgroup = ColumnWidthCALC(tCellNode, colgroup);
                                                }

                                                HtmlNodeCollection tCellChildNodes = tCellNode.ChildNodes;
                                                if (tCellChildNodes.Count > 0)
                                                {
                                                    foreach (HtmlNode tCellChildNode in tCellChildNodes)
                                                    {
                                                        cell = GenerateSecXSLT_TMPL(tCellChildNode, cell);
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                XmlNode cell = GenerateSecXSLT_TMPL(tCellNode, tRow);
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    XmlNode row = GenerateSecXSLT_TMPL(tRowNode, tSec);
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("NO 'thead' or 'tbody' Nodes Found in Table Node: " + node.Name);
            }

            divMain.Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
            ctrlNr++;
            return divMain;
        }


        private static XmlNode XSLT_TemplateContainerNode(HtmlNode node)
        {
            /*Container Node Tag Name - div*/
            XmlNode div = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("ContainerDef").FirstChild, true);

            div = CopyNodeStyleAttri(node, div);
            div.Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
            ctrlNr++;

            HtmlNodeCollection containerList = node.ChildNodes;
            if (containerList.Count > 0)
            {
                foreach (HtmlNode containerNode in containerList)
                {
                    XmlNode containerElement = GenerateSecXSLT_TMPL(containerNode, div);
                }
            }
            return div;
        }


        private static XmlNode XSLT_TemplateHeadingNode(HtmlNode node)
        {
            XmlNode div = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("HeadingDef").FirstChild, true);
            div.InnerXml = Regex.Replace(div.InnerXml, "HEADING_TEXT", node.InnerText);
            div = CopyNodeStyleAttri(node, div);
            return div;
        }


        private static XmlNode XSLT_TemplateLabelNode(HtmlNode node)
        {
            XmlNode div = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("LabelDef").FirstChild, true);
            div.FirstChild.InnerText = node.InnerText;
            return div;
        }


        private static XmlNode XSLT_TemplateTextBoxElement(HtmlNode node)
        {
            XmlNode span = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("TextBoxDef").FirstChild, true);

            if ((node.Attributes["id"] != null) && (node.Attributes["id"].Value != ""))
            {
                span.Attributes["xd:binding"].Value = nodePrefix + ":" + node.Attributes["id"].Value;
                if (span.InnerXml.Contains("LEAF_XPATH1"))
                {
                    span.InnerXml = Regex.Replace(span.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + node.Attributes["id"].Value);
                }
            }

            span = CopyNodeStyleAttri(node, span);
            span.Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
            ctrlNr++;
            return span;
        }


        private static XmlNode XSLT_TemplateCheckBoxElement(HtmlNode node)
        {
            XmlNode CheckBoxDef = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("CheckBoxDef"), true);
            string id = "";
            if ((node.HasAttributes) && (node.Attributes["id"] != null))
            {
                id = node.Attributes["id"].Value;
            }
            else if ((node.SelectSingleNode("input").HasAttributes) && (node.SelectSingleNode("input").Attributes["id"] != null))
            {
                id = node.SelectSingleNode("input").Attributes["id"].Value;
            }
            CheckBoxDef.InnerXml = Regex.Replace(CheckBoxDef.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + id);
            //CheckBoxDef.InnerXml = Regex.Replace(CheckBoxDef.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + node.SelectSingleNode("input").Attributes["id"].Value);

            XmlNode input = CheckBoxDef.FirstChild;
            input = CopyNodeStyleAttri(node, input);
            input.Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
            ctrlNr++;

            return input;
        }


        private static XmlNode XSLT_TemplateOptionButtonsElement(HtmlNode node, int index)
        {
            /* Option Buttons element Tag Name - input*/
            XmlNode OptionButtonDef = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("OptionButtonDef"), true);
            string groupId = "OptionGroup";

            if ((node.Attributes["Id"] != null) && (node.Attributes["id"].Value != ""))
            {
                groupId = node.Attributes["Id"].Value;
            }
            else if ((node.ParentNode.Attributes["Id"] != null) && (node.ParentNode.Attributes["id"].Value != ""))
            {
                groupId = node.ParentNode.Attributes["Id"].Value;
            }
            OptionButtonDef.InnerXml = Regex.Replace(OptionButtonDef.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + groupId);
            OptionButtonDef.InnerXml = Regex.Replace(OptionButtonDef.InnerXml, "OB_NUM", index.ToString());
            OptionButtonDef.InnerXml = Regex.Replace(OptionButtonDef.InnerXml, "CONTROL_ID", "CTRL" + ctrlNr);

            XmlNode input = OptionButtonDef.FirstChild;
            ctrlNr++;
            return input;
        }


        private static XmlNode XSLT_TemplateDropDownListElement(HtmlNode node)
        {
            HtmlNodeCollection optionNodes = node.SelectNodes("option");
            XmlNode select;
            XmlNode optionTMPL;
            string groupId = "DropDownList";

            if ((optionNodes == null) || ((optionNodes != null) && (optionNodes.Count == 1) && (optionNodes[0].Name == "Select...")))
            {
                if (node.OuterHtml.Contains("</script>"))
                {
                    select = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("DropDownListDef").ChildNodes[2], true);
                    string scriptNodeStr = node.SelectSingleNode("script").InnerHtml;
                    XmlNode scriptNode = xsltTMPL.CreateNode(XmlNodeType.Element, "", "script", "");                    
                    scriptNode.InnerXml = scriptNodeStr;
                    select.AppendChild(scriptNode);
                }
                else
                {
                    // Options will be read from Data Connection.
                    select = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("DropDownListDef").ChildNodes[1], true);
                }

                string dbXPath = "";
                select.InnerXml = Regex.Replace(select.InnerXml, "REPEATING_LEAF_XPATH_DB", dbXPath);

                string dbColumnName = "";
                select.InnerXml = Regex.Replace(select.InnerXml, "LEAF_XPATH_ELEMENT", "@" + dbColumnName);

            }
            //else if ((optionNodes != null) && (optionNodes.Count > 0))
            else
            {
                select = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("DropDownListDef").FirstChild, true);
                optionTMPL = select.SelectSingleNode("option").CloneNode(true);

                foreach (HtmlNode tmp in optionNodes)
                {
                    XmlNode op;
                    if (tmp != optionNodes[0])
                    {
                        op = optionTMPL.CloneNode(true);
                        select.AppendChild(op);
                    }

                    op = select.LastChild;
                    if ((tmp.HasAttributes) && (tmp.Attributes["value"] != null) && (tmp.Attributes["value"].Value != ""))
                    {
                        op.Attributes["value"].Value = tmp.Attributes["value"].Value;
                        op.InnerXml = Regex.Replace(op.InnerXml, "OPTION_VALUE", tmp.Attributes["value"].Value);
                    }
                    else
                    {
                        op.Attributes["value"].Value = "";
                        op.InnerXml = Regex.Replace(op.InnerXml, "OPTION_VALUE", "");
                    }
                    op.InnerXml += tmp.InnerText;
                }
            }       

            if((node.HasAttributes) && (node.Attributes["Id"] != null))
            {
                groupId = node.Attributes["id"].Value;
            }

            select.Attributes["xd:binding"].Value = nodePrefix + ":" + groupId;
            select.InnerXml = Regex.Replace(select.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + groupId);

            //nodePrefix + ":" + node.Attributes["Id"].Value
            select.Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
            ctrlNr++;

            return select;
        }


        private static XmlNode XSLT_TemplateLinkElement(HtmlNode node)
        {
            XmlNode LinkDef = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("LinkDef"), true);
            XmlNode span = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("LinkDef").FirstChild, true);
            span.Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
            ctrlNr++;

            if (node.SelectSingleNode("//span").Attributes["id"] != null)
            {
                span.Attributes["xd:binding"].Value = nodePrefix + ":" + node.SelectSingleNode("//span").Attributes["id"].Value;
                span.InnerXml = Regex.Replace(span.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + node.SelectSingleNode("//span").Attributes["id"].Value);
            }
            else
            {
                Random rnd = new Random();
                int index = rnd.Next(1000);
                span.Attributes["xd:binding"].Value = nodePrefix + ":" + "Link" + index;
                span.InnerXml = Regex.Replace(span.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + "Link" + index);
            }

            span = CopyNodeStyleAttri(node, span);
            return span;
        }


        private static XmlNode XSLT_TemplateImageElement(HtmlNode node)
        {
            XmlNode div = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("ImageDef").FirstChild, true);
            if (node.SelectSingleNode("//img").Attributes["id"] != null)
            {
                div.InnerXml = Regex.Replace(div.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + node.SelectSingleNode("//img").Attributes["id"].Value);
            }
            else
            {
                Random rnd = new Random();
                int index = rnd.Next(1000);
                div.InnerXml = Regex.Replace(div.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + "Image" + index);
            }

            XmlNode img = div.SelectSingleNode("//img");
            img.Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
            ctrlNr++;

            return div;
        }


        private static XmlNode XSLT_TemplateButtonElement(HtmlNode node)
        {
            XmlNode div = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("ButtonDef").FirstChild, true);
            XmlNode input = div.SelectSingleNode("//input");

            input = CopyNodeStyleAttri(node, input);

            if (node.Attributes["type"].Value == "button")
            {
                div.SelectSingleNode("//input").Attributes["value"].Value = "Button";
            }
            else if (node.Attributes["type"].Value == "summit")
            {
                div.SelectSingleNode("//input").Attributes["value"].Value = "Summit";
            }

            if (node.Attributes["id"] != null)
            {
                div.SelectSingleNode("//input").Attributes["xd:CtrlId"].Value = node.Attributes["id"].Value;
            }
            else
            {
                div.SelectSingleNode("//input").Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
                ctrlNr++;
            }

            return div;
        }


        private static XmlNode XSLT_TemplateInputFileElement(HtmlNode node)
        {
            XmlNode span = xsltTMPL.ImportNode(elemDefinitionDoc.DocumentElement.SelectSingleNode("InputFileDef").FirstChild, true);

            span.Attributes["xd:CtrlId"].Value = "CTRL" + ctrlNr;
            ctrlNr++;

            span.InnerXml = Regex.Replace(span.InnerXml, "LEAF_XPATH1", nodePrefix + ":" + node.Attributes["id"].Value);
            span.Attributes["xd:binding"].Value = nodePrefix + ":" + node.Attributes["id"].Value;

            return span;
        }

    }

    public class HtmltoXML
    {
        static String file;
        static string nodePrefix = Transformation.Program.nodePrefix;
        static string nameSpaceDateTime = Transformation.Program.nameSpaceDateTime;
        static string generateXmlPath = Transformation.Program.generateXmlPath;

        public static void TranformHtmltoXML(HtmlNodeCollection htmlBodyNodes)
        {
            /* Generation of XML File from BootStrap HTML. */
            using (System.IO.StreamWriter filexml = new System.IO.StreamWriter(generateXmlPath, false))
            {
                filexml.WriteLine("<?xml version = \"1.0\" encoding = \"UTF-8\" ?>");
                filexml.WriteLine("<" + nodePrefix + ":" + "myFields xmlns:" + nodePrefix +
                    "=" + nameSpaceDateTime + @""">");
                GenerateXml(htmlBodyNodes);
                filexml.WriteLine(file + "\n</" + nodePrefix + ":" + "myFields >");
            }

        }

        private static void GenerateXml(HtmlNodeCollection divnodes)
        {
            foreach (var node in divnodes)
            {
                if (node.Name != "button" && node.Name != "a") // && !node.Name.Contains("#")
                {
                    var val = "";
                    if (node.Name.Equals("input") || node.Name.Equals("textarea"))
                    {
                        val = node.GetAttributeValue("value", "");
                        if (node.GetAttributeValue("type", "").Equals("checkbox") | node.GetAttributeValue("type", "").Equals("radio"))
                        {
                            val = node.GetAttributeValue("checked", "");
                        }
                    }
                    else if (node.Name.Equals("option"))
                    {
                        val = node.GetAttributeValue("selected", "");
                    }
                    else if (node.Name.Equals("img"))
                    {
                        val = node.GetAttributeValue("src", "");
                    }
                    else if (node.Name.Equals("a"))
                    {
                        val = node.GetAttributeValue("href", "");
                    }

                    if (node.Id != "")
                    {
                        file = file + ("\n<" + nodePrefix + ":" + node.Id + ">" + val);
                    }

                    if (node.HasChildNodes)
                    {
                        var childNodes = node.ChildNodes;
                        foreach (var childNode in childNodes)
                        {
                            if (childNode.Name != "button" && childNode.Name != "a")    // && !childNode.Name.Contains("#")
                            {
                                var valch = "";
                                if (childNode.Name.Equals("input") || childNode.Name.Equals("textarea"))
                                {
                                    valch = childNode.GetAttributeValue("value", "");
                                    if (childNode.GetAttributeValue("type", "").Equals("checkbox") | childNode.GetAttributeValue("type", "").Equals("radio"))
                                    {
                                        valch = childNode.GetAttributeValue("checked", "");
                                    }
                                }
                                else if (childNode.Name.Equals("option"))
                                {
                                    valch = childNode.GetAttributeValue("selected", "");
                                }
                                else if (childNode.Name.Equals("img"))
                                {
                                    valch = childNode.GetAttributeValue("src", "");
                                }
                                else if (childNode.Name.Equals("a"))
                                {
                                    valch = childNode.GetAttributeValue("href", "");
                                }

                                if (childNode.Id != "")
                                {
                                    file = file + ("\n<" + nodePrefix + ":" + childNode.Id + ">" + valch);
                                }

                                HtmlNodeCollection n = new HtmlNodeCollection(childNode);
                                GenerateXml(childNode.ChildNodes);

                                if (childNode.Id != "")
                                {
                                    file = file + ("\n</" + nodePrefix + ":" + childNode.Id + ">\n");
                                }
                            }
                        }

                    }
                    if (node.Id != "")
                    {
                        file = file + ("</" + nodePrefix + ":" + node.Id + ">");
                    }
                }
            }
        }
    }

}
