﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Regex;
using HtmlTransformation;

namespace Transformation
{
    class Program
    {
        static int htmlFileNr = 8;                                      // Give the number of html file in testFileInfo.xml File.
        public static string nodePrefix = "my";
        public static string testElementName;                           
        public static string generateDateTime;                          
        public static string nameSpaceDateTimeXsl;                     
        public static string htmlPath;                                  
        public static string generateXmlPath;                           
        public static string generateXsltPath;                          
        public static string nameSpaceDateTime;                         

        public static HtmlDocument htmlDoc = new HtmlDocument();        // For Web Form HTML in Bootstrap Format
        public static XmlDocument elemDefinitionDoc = new XmlDocument();
        public static XmlDocument xsltTMPL = new XmlDocument();         // For the InfoPath XSLT Template File in XML Format

        static string infopathHtmlPath = @"..\TestExamples\InfoPathHtmlFiles\rainbird.htm";
        public static HtmlDocument infopathHtmlDoc = new HtmlDocument();
        public static HtmlDocument newBootStrapHTMLDoc = new HtmlDocument();
        public static HtmlDocument newBootStrapHTMLBackUpInfoDoc = new HtmlDocument();
        public static string bootStrapHTMLDocPath = @"..\TestExamples\InfoPathHtmlFiles\newBootStrapForm.html";
        public static string bootStrapHTMLBackUpInfoDocPath = @"..\TestExamples\InfoPathHtmlFiles\newBootStrapFormBackUpInfo.html";
        public static HtmlNodeCollection viewElementArray;


        static void Main(string[] args)
        {
            BootstrapHtmlParsing(htmlFileNr);
            InfoPathHtmlParsing();           
        }   // THE END


        /* ---- TRANSFORMATION FROM INFOPATH HTML TO BOOTSTRAP HTML ---- */
        private static void InfoPathHtmlParsing()
        {
            // load Infopath generated Html as the original file. Analysis the DOM nodes and copy the neccesary info to the bootstrap html file.
            if(infopathHtmlPath.StartsWith("http"))
            {
                HtmlWeb web = new HtmlWeb();
                infopathHtmlDoc = web.Load(infopathHtmlPath);
            }
            else
            {
                infopathHtmlDoc.Load(infopathHtmlPath);
            }


            // Load a BootStrap HTML Doc from a Template File
            newBootStrapHTMLDoc.Load("bootStrapHtmlTemplate.html");

            var xdocViewNodes = infopathHtmlDoc.DocumentNode.SelectNodes("//div[@id='xdoc']//div[@id='xdoc_view']");
            foreach (var xdocViewNode in xdocViewNodes)
            {
                // Copy <div id="xdoc_form"> part to a separate File for future use.
                HtmlNode xdocFormNode = xdocViewNode.NextSibling;
                newBootStrapHTMLBackUpInfoDoc.DocumentNode.AppendChild(xdocFormNode);

                // Tranform <div id="xdoc_view"> Part to BootStrap Format.
                HtmlNode newDocViewNode = XDocViewNodeTranformation(xdocViewNode);
                newBootStrapHTMLDoc.DocumentNode.SelectSingleNode("//body").AppendChild(newDocViewNode);
            }


            HtmlNode headNode = infopathHtmlDoc.DocumentNode.SelectSingleNode("//head");
            foreach (var xNode in headNode.ChildNodes)
            {
                newBootStrapHTMLDoc.DocumentNode.SelectSingleNode("//head").AppendChild(xNode);
            }

            // Save BootStrap Format HtmlDocument in a HTML File.
            SaveHTMLDocumentToFile(newBootStrapHTMLDoc, bootStrapHTMLDocPath);
            // Save the Form Structure Info in a Separate HTML File.
            SaveHTMLDocumentToFile(newBootStrapHTMLBackUpInfoDoc, bootStrapHTMLBackUpInfoDocPath);
        }


        private static HtmlNode XDocViewNodeTranformation(HtmlNode xdocView)
        {
            // Loop through every node in xdocView, and modify the InfoPath related attributes.(including Class Value, "xd:" Attributes, tabIndex attribute)
            viewElementArray = xdocView.SelectNodes(".//*");

            foreach (HtmlNode cell in viewElementArray)
            {
                if (cell.HasAttributes)
                {
                    NodeClassAttriConvert(cell);
                }
            }
            return xdocView;
        }

        private static HtmlNode NodeClassAttriConvert(HtmlNode attriNode)
        {
            if (attriNode.HasAttributes)                
            {
                HtmlAttributeCollection attriArray = attriNode.Attributes;
                HtmlAttributeCollection tmpAttriArray = attriArray;

                for (int i = tmpAttriArray.Count - 1; i >= 0; i--)
                {
                    if (tmpAttriArray[i].Name == "class")
                    {
                        string classAttriValue = attriNode.Attributes["class"].Value;

                        if (classAttriValue.StartsWith("xdSection"))
                        {   // Section
                            attriNode.Attributes["class"].Value = "form-group";
                        }
                        else if (classAttriValue.StartsWith("xdLayout"))
                        {   // Table
                            attriNode.Attributes["class"].Value = "table";
                        }
                        else if ((classAttriValue.StartsWith("xdTextBox")) || (classAttriValue.StartsWith("xdTextBoxRTL")))
                        {   // TextBox
                            attriNode.Attributes["class"].Value = "form-control";
                        }
                        else if (classAttriValue.StartsWith("xdComboBox") && (attriNode.Name == "span"))
                        {   // ComboBox
                            attriNode.Attributes["class"].Value = "comboBox";       // NO ComboBox Element in the web editor
                        }
                        else if (classAttriValue.StartsWith("xdDTPicker"))
                        {   // Date Picker
                            attriNode.Attributes["class"].Value = "datePicker";     // NO DatePicker Element in the web editor
                        }
                        else if (classAttriValue.StartsWith("xdComboBox") && (attriNode.Name == "select"))
                        {   // Drop Down List
                            attriNode.Attributes["class"].Value = "form-group";
                        }
                        else if (classAttriValue.StartsWith("langFont") && (attriNode.Attributes["type"].Value == "button"))
                        {   // Button
                            attriNode.Name = "button";
                        }
                        else if (classAttriValue.StartsWith("xdBehavior_Boolean") && (attriNode.Attributes["type"].Value == "radio"))
                        {   // Option Button
                            attriNode.Attributes["class"].Value = "radio";
                        }
                        else if (classAttriValue.StartsWith("xdBehavior_Boolean") && (attriNode.Attributes["type"].Value == "checkbox"))
                        {   // Check Box
                            attriNode.Attributes["class"].Value = "checkbox";
                        }
                        else if (classAttriValue.StartsWith("xdFileAttachment") && (attriNode.Name == "span"))
                        {   // File Attachment
                            attriNode.Attributes["class"].Value = "form-group";
                            HtmlAttribute type = infopathHtmlDoc.CreateAttribute("type", "file");
                            attriNode.Attributes.Append(type);
                        }
                        else if (classAttriValue.StartsWith("xdHyperlink") && (attriNode.Name == "span"))
                        {   // Hyper Link
                            attriNode.Attributes["class"].Value = "d-inline-block";
                        }
                        else if (classAttriValue.StartsWith("xdDataBindingUI") && (attriNode.Name == "a"))
                        {   // Hyper Link
                            attriNode.Attributes["class"].Value = "d-inline-block";
                        }
                    }
                    else if ((tmpAttriArray[i].Name.StartsWith("xd:")) || (tmpAttriArray[i].Name.ToLower() == "tabindex"))
                    {
                        string attriName = tmpAttriArray[i].Name;
                        HtmlAttribute tmp = attriNode.Attributes[attriName];
                        attriNode.Attributes.Remove(tmp);
                    }
                    else if (tmpAttriArray[i].Value.StartsWith("InfoJet"))
                    {
                        attriNode.Attributes.Remove(attriArray[i]);
                    }
                }
            }
            return attriNode;
        }


        private static void SaveHTMLDocumentToFile(HtmlDocument doc, string filePath)
        {
            FileStream sw = new FileStream(filePath, FileMode.Create);
            doc.Save(sw);
        }



        /* ---- TRANSFORMATION FROM BOOTSTRAP HTML TO INFOPATH XML AND XSLT ---- */
        private static void BootstrapHtmlParsing(int htmlFileNr)
        {
            /* Read Bootstrap HTML fileName and generatedTime from testFileInfo.xml File */
            XmlDocument testFileInfo = new XmlDocument();
            testFileInfo.Load("testFileInfo.xml");
            readTestHTMLFileInfo(testFileInfo, htmlFileNr);

            /* Load BootStrap HTML File, Finding nodes using XPath (several body node in html may occur in current BootStrap Web Form Editor).*/
            htmlDoc.Load(htmlPath);
            xsltTMPL.Load("xslTemplate.xsl");
            elemDefinitionDoc.Load("InfoPathElementDefinition.xml");

            /* Select all body nodes  and Remove unnecessary empty nodes (eg: #test). */
            var htmlBodyNodes = htmlDoc.DocumentNode.SelectNodes("//body");
            for (int i = 0; i < htmlBodyNodes.Count; i++)
            {
                HtmlNodeCollection childNodeList = htmlBodyNodes[i].ChildNodes;
                RemoveEmptyNode(childNodeList);
            }

            /* Transformation from BootStrap HTML to XSLT File*/
            HtmlTransformation.HtmltoXSLT.TransformHtmltoXslt(htmlBodyNodes, xsltTMPL);

            /* Transformation from BootStrap HTML to XML File*/
            HtmlTransformation.HtmltoXML.TranformHtmltoXML(htmlBodyNodes);
        }


        private static void readTestHTMLFileInfo(XmlDocument testFileInfo, int htmlFileNr)
        {
            var htmlFileNodes = testFileInfo.DocumentElement.SelectNodes("//testFile");
            testElementName = htmlFileNodes[htmlFileNr].SelectSingleNode("fileName").InnerText;
            generateDateTime = htmlFileNodes[htmlFileNr].SelectSingleNode("generatedTime").InnerText;

            nameSpaceDateTimeXsl = $"http://schemas.microsoft.com/office/infopath/2003/myXSD/" + generateDateTime;
            htmlPath = @"..\TestExamples\" + testElementName + @"\BootstrapForm\" + testElementName + ".html";
            generateXmlPath = @"..\TestExamples\" + testElementName + @"\xmlFile.xml";
            generateXsltPath = @"..\TestExamples\" + testElementName + @"\compare1\view1.xsl";
            nameSpaceDateTime = @"""http://schemas.microsoft.com/office/infopath/2003/myXSD/" + generateDateTime;
        }


        private static void RemoveEmptyNode(HtmlNodeCollection NodeList)
        {
            foreach (HtmlNode node in NodeList.Reverse())
            {
                if (node.HasChildNodes)
                {
                    HtmlNodeCollection grandNodeList = node.ChildNodes;
                    RemoveEmptyNode(grandNodeList);
                }
                else if (node.Name.Contains("#"))
                {
                    string str = node.InnerText;
                    str = Regex.Replace(str, @"\r\n", "");
                    str = Regex.Replace(str, @"\t", "");
                    node.InnerHtml = str;
                    str = Regex.Replace(str, " ", "");

                    if (str == "")
                    {
                        NodeList.Remove(node);
                    }
                }
            }
        }


    }
}
